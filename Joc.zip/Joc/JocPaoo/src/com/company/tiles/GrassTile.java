package com.company.tiles;

import com.company.gfx.Assets;

public class GrassTile extends Tile{

    public GrassTile(int id) {
        super(Assets.grass, id);
    }
}
